const token = 'YOUR_ADMIN_JWT_TOKEN'; // Replace with the actual token from login

// Fetch and display users
document.getElementById('fetchUsers').addEventListener('click', async () => {
  try {
    const response = await fetch('http://localhost:3000/api/users', {
      headers: {
        'Authorization': token,
      },
    });
    const users = await response.json();
    const usersList = document.getElementById('usersList');
    usersList.innerHTML = `
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          ${users.map(user => `
            <tr>
              <td>${user._id}</td>
              <td>${user.name}</td>
              <td>${user.email}</td>
              <td>${user.role}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  } catch (error) {
    console.error('Error fetching users:', error);
  }
});

// Fetch and display products
document.getElementById('fetchProducts').addEventListener('click', async () => {
  try {
    const response = await fetch('http://localhost:3000/api/products', {
      headers: {
        'Authorization': token,
      },
    });
    const products = await response.json();
    const productsList = document.getElementById('productsList');
    productsList.innerHTML = `
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>Category</th>
          </tr>
        </thead>
        <tbody>
          ${products.map(product => `
            <tr>
              <td>${product._id}</td>
              <td>${product.name}</td>
              <td>$${product.price}</td>
              <td>${product.category}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  } catch (error) {
    console.error('Error fetching products:', error);
  }
});